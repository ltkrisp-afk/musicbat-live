# Restore isolated source

Required: Node >=22.13 (validated on installed Node 24), pnpm as declared in package.json, compatible platform dependencies. No credentials are bundled.

1. Unzip this archive into an empty directory. Verify each payload against manifest.json.
2. `git clone -b live-experience-verification musicbat-live-experience.bundle musicbat-restored`
3. `cd musicbat-restored` then `git rev-parse HEAD`; expected `7f71f67d99c4e5467558723a444c16905e4faf10`.
4. Install dependencies with the current supported installer or `npm run install:ci`.
5. Run `npm test`, `npm run typecheck`, `npm run lint`, `npm run build`.
6. See engineering-report.md for supervised configuration, browser/audio and Stripe verification blockers. No restore command authorizes production changes or deployment.

musicbat-source.tar.gz supplies the same tracked source without history. The bundle contains complete ancestors for this branch. previous-verified-recovery.zip retains the earlier independent recovery material; its completed verification was not repeated.

Archive SHA-256 is recorded in the external MusicBat_Live_Experience_Manifest_2026-10-12.md to avoid self-referential hashing.
